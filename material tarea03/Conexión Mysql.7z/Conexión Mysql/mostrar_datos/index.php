Mostrar todos los usuarios:

Enunciado: Crea un formulario que permita mostrar todos los usuarios de la tabla usuarios.
<!-- formulario.php -->
<form action="mostrar.php" method="post">
    <input type="submit" value="Mostrar Usuarios">
</form>
