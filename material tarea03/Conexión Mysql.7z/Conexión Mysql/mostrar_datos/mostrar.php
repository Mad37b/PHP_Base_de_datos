<!-- mostrar.php -->
<?php
$user = 'tu_usuario';
$host = 'localhost';
$db = 'tu_base_de_datos';
$pass = 'tu_contraseña';

$conexion = mysqli_connect($host, $user, $pass, $db);

if (!$conexion) {
    die("Error en la conexión: " . mysqli_connect_error());
}

$consulta = "SELECT * FROM usuarios";
$resultado = mysqli_query($conexion, $consulta);

if ($resultado) {
    while ($fila = mysqli_fetch_assoc($resultado)) {
        echo "ID: " . $fila['id'] . "<br>";
        echo "Nombre: " . $fila['nombre'] . "<br>";
        echo "Correo: " . $fila['correo'] . "<br>";
        echo "-------------------------<br>";
    }
} else {
    echo "Error al mostrar usuarios: " . mysqli_error($conexion);
}

mysqli_close($conexion);
?>