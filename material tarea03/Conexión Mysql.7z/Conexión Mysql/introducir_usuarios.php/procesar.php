<!-- procesar.php -->
<?php
$user = 'root';
$host = 'localhost';
$db = 'tu_base_de_datos';
$pass = '';

$conexion = mysqli_connect($host, $user, $pass, $db);

if (!$conexion) {
    die("Error en la conexión: " . mysqli_connect_error());
}

$nombre = $_POST['nombre'];
$correo = $_POST['correo'];

$consulta = "INSERT INTO usuarios (nombre, correo) VALUES ('$nombre', '$correo')";
if (mysqli_query($conexion, $consulta)) {
    echo "Usuario agregado correctamente";
} else {
    echo "Error al agregar usuario: " . mysqli_error($conexion);
}

mysqli_close($conexion);
?>
