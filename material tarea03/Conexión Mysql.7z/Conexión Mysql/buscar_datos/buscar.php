<!-- buscar.php -->
<?php
$user = 'tu_usuario';
$host = 'localhost';
$db = 'tu_base_de_datos';
$pass = 'tu_contraseña';

$conexion = mysqli_connect($host, $user, $pass, $db);

if (!$conexion) {
    die("Error en la conexión: " . mysqli_connect_error());
}

$nombre = $_POST['nombre'];

$consulta = "SELECT * FROM usuarios WHERE nombre='$nombre'";
$resultado = mysqli_query($conexion, $consulta);

if ($resultado) {
    while ($fila = mysqli_fetch_assoc($resultado)) {
        echo "ID: " . $fila['id'] . "<br>";
        echo "Nombre: " . $fila['nombre'] . "<br>";
        echo "Correo: " . $fila['correo'] . "<br>";
        echo "-------------------------<br>";
    }
} else {
    echo "Error al buscar usuario: " . mysqli_error($conexion);
}

mysqli_close($conexion);
?>
