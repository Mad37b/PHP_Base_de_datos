Buscar usuario por nombre:

Enunciado: Crea un formulario que permita buscar un usuario por su nombre en la tabla usuarios.
<!-- formulario.php -->
<form action="buscar.php" method="post">
    Nombre del usuario a buscar: <input type="text" name="nombre"><br>
    <input type="submit" value="Buscar Usuario">
</form>
