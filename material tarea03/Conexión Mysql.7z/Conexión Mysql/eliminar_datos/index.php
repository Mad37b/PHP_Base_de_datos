Eliminar usuario:

Enunciado: Crea un formulario que permita eliminar un usuario de la tabla usuarios.
<!-- formulario.php -->
<form action="eliminar.php" method="post">
    ID del usuario a eliminar: <input type="text" name="id"><br>
    <input type="submit" value="Eliminar Usuario">
</form>
