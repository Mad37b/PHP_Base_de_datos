<!-- actualizar.php -->
<?php
$user = 'tu_usuario';
$host = 'localhost';
$db = 'tu_base_de_datos';
$pass = 'tu_contraseña';

$conexion = mysqli_connect($host, $user, $pass, $db);

if (!$conexion) {
    die("Error en la conexión: " . mysqli_connect_error());
}

$id = $_POST['id'];
$nuevo_correo = $_POST['nuevo_correo'];

$consulta = "UPDATE usuarios SET correo='$nuevo_correo' WHERE id=$id";
if (mysqli_query($conexion, $consulta)) {
    echo "Correo actualizado correctamente";
} else {
    echo "Error al actualizar correo: " . mysqli_error($conexion);
}

mysqli_close($conexion);
?>
