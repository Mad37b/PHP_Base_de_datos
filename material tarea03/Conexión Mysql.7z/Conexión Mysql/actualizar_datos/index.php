Actualizar información de usuario:

Enunciado: Crea un formulario que permita actualizar el correo de un usuario existente en la tabla usuarios.
<!-- formulario.php -->
<form action="actualizar.php" method="post">
    ID del usuario a actualizar: <input type="text" name="id"><br>
    Nuevo correo: <input type="text" name="nuevo_correo"><br>
    <input type="submit" value="Actualizar Correo">
</form>
