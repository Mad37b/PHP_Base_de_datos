<?php
/*
 * Enunciado:
Permitir a los usuarios actualizar la información de un producto existente. Mostrar un formulario con los datos actuales y permitir al usuario modificarlos.
 */

require_once 'conexion.php';
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id_producto = $_POST["id_producto"];
    $nuevo_precio = $_POST["nuevo_precio"];

    

    $stmt = $conexion->prepare("UPDATE productos SET pvp = ? WHERE id = ?");
    $stmt->bind_param("di", $nuevo_precio, $id_producto);

    if ($stmt->execute()) {
        echo "Precio actualizado correctamente.";
    } else {
        echo "Error al actualizar el precio: " . $stmt->error;
    }

    $stmt->close();
    $conexion->close();
}
