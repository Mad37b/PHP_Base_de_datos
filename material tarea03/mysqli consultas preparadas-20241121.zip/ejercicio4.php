<?php
//Permitir a los usuarios buscar productos por nombre. Mostrar los resultados en una lista.



if ($_SERVER["REQUEST_METHOD"] == "POST") {

    // Sanitizar datos del formulario
    $nombre_buscado = htmlspecialchars($_POST["nombre_buscado"]);

    require_once 'conexion.php';
    // Preparar la consulta con marcadores de posición
    $stmt = $conexion->prepare("SELECT id, nombre, pvp FROM productos WHERE nombre LIKE ?");

    // Sanitizar y asignar el valor al marcador de posición
    $nombre_buscado = "%" . $conexion->real_escape_string($nombre_buscado) . "%";
    $stmt->bind_param("s", $nombre_buscado);

    // Ejecutar la consulta
    $stmt->execute();

    // Obtener resultados
    $result = $stmt->get_result();

    echo "<ul>";
    while ($row = $result->fetch_assoc()) {
        echo "<li>ID: " . $row['id'] . ", Nombre: " . $row['nombre'] . ", Precio: " . $row['pvp'] . "</li>";
    }
    echo "</ul>";

    echo "<button><a href='formulario4.php'>Volver al formulario</a></button>";

    // Cerrar recursos
    $stmt->close();
    $conexion->close();
}
?>

