<?php 
//Enunciado: Obtén el nombre y el teléfono de todas las tiendas.

require_once 'conexion.php';
$stmt = $conexion->prepare("SELECT nombre, tlf FROM tiendas");
$stmt->execute();

//Es importante notar que al utilizar bind_result(), debes proporcionar tantas variables como columnas en el resultado de la consulta. 
$stmt->bind_result($nombre, $tlf);

// Mostrar resultados
while ($stmt->fetch()) { //Devuelve una fila de los resultados en cada iteración
    echo "Nombre: " . $nombre . ", Teléfono: " . $tlf . "<br>";
}

$stmt->close();
$conexion->close();
