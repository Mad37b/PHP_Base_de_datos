<?php

//Enunciado:
//Permitir a los usuarios eliminar un producto. Mostrar una lista de productos y permitir al usuario seleccionar uno para eliminar.

require_once 'conexion.php';
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id_producto = $_POST["id_producto"];

   

    $stmt = $conexion->prepare("DELETE FROM productos WHERE id = ?");
    $stmt->bind_param("i", $id_producto);

    if ($stmt->execute()) {
        echo "Producto eliminado correctamente.";
    } else {
        echo "Error al eliminar el producto: " . $stmt->error;
    }

    $stmt->close();
    $conexion->close();
}
?>
