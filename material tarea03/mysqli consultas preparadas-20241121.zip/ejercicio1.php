<?php
/*
Las dos opciones principales para tratar los resultados de una consulta preparada en MySQLi son bind_result() y get_result().

--> bind_result(): Se utiliza cuando estás seleccionando columnas específicas y deseas vincularlas a variables para procesar los resultados. Es útil cuando no necesitas el conjunto completo de resultados en un array, sino que trabajas con una fila a la vez.

--> get_result(): Se utiliza cuando deseas obtener todos los resultados en un array asociativo. Esto facilita el manejo de los datos en un formato más estructurado.
*/
//Enunciado: Obtén todos los productos de la familia 'NETBOK'.

require_once 'conexion.php';
// Conexión a la base de datos (suponiendo que ya tienes la conexión establecida)

$familia = 'NETBOK';

$stmt = $conexion->prepare("SELECT * FROM productos WHERE familia = ?");
$stmt->bind_param("s", $familia);
$stmt->execute();
$result = $stmt->get_result();

// Mostrar resultados
while ($row = $result->fetch_assoc()) {
    echo "ID: " . $row['id'] . ", Nombre: " . $row['nombre'] . ", Precio: " . $row['pvp'] . "<br>";
}

$stmt->close();
$conexion->close();
?>
