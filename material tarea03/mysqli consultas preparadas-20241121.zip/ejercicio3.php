<?php
//Enunciado: Obtén la cantidad de productos en cada tienda.

require_once 'conexion.php';

$stmt = $conexion->prepare("SELECT t.nombre as tienda, p.nombre as producto, s.unidades FROM tiendas t  JOIN stocks s ON t.id = s.tienda
           JOIN productos p ON s.producto = p.id");
$stmt->execute();
$result = $stmt->bind_result($nombre,$tienda,$unidades);
while ($stmt->fetch()){
    echo $nombre .' ' . $tienda .' ' . $unidades. '<br>';
}
/*
$result = $stmt->get_result();

// Mostrar resultados
while ($row = $result->fetch_assoc()) {
    echo "Tienda: " . $row['tienda'] . ", Producto: " . $row['producto'] . ", Unidades: " . $row['unidades'] . "<br>";
}
*/
$stmt->close();
$conexion->close();
?>
