<?php 

$host = 'localhost';
$user = 'gestor';
$db = 'proyecto';
$pass = 'secreto'; // Suponiendo que 'secreto' es tu contraseña real

try {
    $conexion = new mysqli($host, $user, $pass, $db);

    if($conexion->connect_error){
        die('Error en la conexión: ' . $conexion->connect_error);
    }
    
    echo 'Conexión exitosa <br>'; // Esta línea es opcional y se puede quitar en producción.
} catch (Exception $e) {
    die("Error al intentar la conexión: " . $e->getMessage());
}
?>
