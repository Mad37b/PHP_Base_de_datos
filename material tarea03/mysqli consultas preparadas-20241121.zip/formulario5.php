<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Eliminar Producto</title>
</head>
<body>
    <h2>Eliminar Producto</h2>
    <form action="ejercicio5.php" method="post">
        <label for="id_producto">ID del Producto a Eliminar:</label>
        <input type="number" id="id_producto" name="id_producto" required>
        <br>
        <button type="submit">Eliminar</button>
    </form>
</body>
</html>
