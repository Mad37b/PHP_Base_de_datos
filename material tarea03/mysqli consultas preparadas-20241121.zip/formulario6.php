<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Actualizar Precio</title>
</head>
<body>
    <h2>Actualizar Precio</h2>
    <form action="ejercicio6.php" method="post">
        <label for="id_producto">ID del Producto:</label>
        <input type="number" id="id_producto" name="id_producto" required>
        <br>
        <label for="nuevo_precio">Nuevo Precio:</label>
        <input type="number" step="0.01" id="nuevo_precio" name="nuevo_precio" required>
        <br>
        <button type="submit">Actualizar Precio</button>
    </form>
</body>
</html>
